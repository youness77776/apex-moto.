package com.apexmoto.velocity

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
