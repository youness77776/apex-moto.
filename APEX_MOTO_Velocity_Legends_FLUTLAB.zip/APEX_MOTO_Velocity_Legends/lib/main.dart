import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/onboarding/onboarding_screen.dart';
import 'screens/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await EasyLocalization.ensureInitialized();
  // Test ads are not requested until an ad unit is explicitly configured.
  await MobileAds.instance.initialize();
  runApp(EasyLocalization(
    supportedLocales: const [
      Locale('ar'), Locale('en'), Locale('fr'), Locale('es'), Locale('pt'),
      Locale('de'), Locale('it'), Locale('tr'), Locale('ru'), Locale('zh'),
      Locale('ja'), Locale('ko'), Locale('hi'), Locale('ur'),
    ],
    path: 'assets/lang',
    fallbackLocale: const Locale('en'),
    child: const ApexMotoApp(),
  ));
}

class ApexMotoApp extends StatelessWidget {
  const ApexMotoApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'APEX MOTO - Velocity Legends',
    debugShowCheckedModeBanner: false,
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: const Color(0xFF090D16),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFFF5A1F), brightness: Brightness.dark),
    ),
    home: const AppGate(),
  );
}

class AppGate extends StatefulWidget {
  const AppGate({super.key});
  @override State<AppGate> createState() => _AppGateState();
}
class _AppGateState extends State<AppGate> {
  bool? completed;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    if (mounted) setState(() => completed = p.getBool('onboarding_done') ?? false);
  }
  @override Widget build(BuildContext context) {
    if (completed == null) return const Scaffold(body: Center(child:CircularProgressIndicator()));
    return completed! ? const HomeScreen() : const OnboardingScreen();
  }
}
