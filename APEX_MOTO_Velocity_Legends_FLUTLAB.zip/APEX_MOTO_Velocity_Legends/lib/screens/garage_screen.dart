import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import '../models/bike.dart';
import '../services/progress_service.dart';
class GarageScreen extends StatefulWidget {const GarageScreen({super.key});@override State<GarageScreen> createState()=>_GarageScreenState();}
class _GarageScreenState extends State<GarageScreen>{int selected=0;int cash=5000;
 @override void initState(){super.initState();ProgressService.cash().then((v)=>setState(()=>cash=v));}
 @override Widget build(BuildContext context){final b=bikes[selected];return Scaffold(appBar:AppBar(title:Text('garage'.tr())),body:Padding(padding:const EdgeInsets.all(18),child:Column(children:[
 const Spacer(),const Icon(Icons.two_wheeler,size:130,color:Color(0xFFFF642D)),Text(b.name,style:const TextStyle(fontSize:25,fontWeight:FontWeight.w900)),Text('${'speed'.tr()}: ${b.maxSpeed} km/h'),Text('${'coins'.tr()}: $cash'),const Spacer(),
 Expanded(child:ListView.builder(itemCount:bikes.length,itemBuilder:(c,i)=>ListTile(selected:i==selected,leading:const Icon(Icons.motorcycle),title:Text(bikes[i].name),subtitle:Text('${bikes[i].maxSpeed} km/h • ${bikes[i].price} ${bikes[i].premium?'G':'\$'}'),onTap:()=>setState(()=>selected=i)))),
 FilledButton(onPressed:()=>ProgressService.saveBike(b.name),child:Text('select_bike'.tr()))
 ])));}
}
