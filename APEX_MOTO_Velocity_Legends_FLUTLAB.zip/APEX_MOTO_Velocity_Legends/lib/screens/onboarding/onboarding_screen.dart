import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../home_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  int? age;
  String country = 'Morocco';
  String language = 'ar';

  Future<void> _continue() async {
    if (age == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please choose your age')),
      );
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('age', age!);
    await prefs.setString('country', country);
    await prefs.setBool('safe_mode', age! < 13);
    await prefs.setBool('onboarding_done', true);
    await context.setLocale(Locale(language));
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const HomeScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Icon(Icons.two_wheeler, size: 92, color: Color(0xFFFF642D)),
                const SizedBox(height: 12),
                const Text('APEX MOTO', textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
                const Text('VELOCITY LEGENDS', textAlign: TextAlign.center,
                  style: TextStyle(letterSpacing: 3, color: Colors.white70)),
                const SizedBox(height: 36),
                Text('choose_age'.tr(), style: const TextStyle(fontSize: 18)),
                const SizedBox(height: 10),
                DropdownButtonFormField<int>(
                  value: age,
                  decoration: const InputDecoration(border: OutlineInputBorder()),
                  items: List.generate(6, (i) => i + 13)
                    .map((v) => DropdownMenuItem(value: v, child: Text('$v+')))
                    .toList(),
                  onChanged: (v) => setState(() => age = v),
                ),
                const SizedBox(height: 20),
                Text('choose_country'.tr(), style: const TextStyle(fontSize: 18)),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  value: country,
                  decoration: const InputDecoration(border: OutlineInputBorder()),
                  items: const ['Morocco', 'Algeria', 'Tunisia', 'Egypt', 'France',
                    'Spain', 'United States', 'United Kingdom', 'Other']
                    .map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
                  onChanged: (v) => setState(() => country = v ?? 'Morocco'),
                ),
                const SizedBox(height: 20),
                Text('choose_language'.tr(), style: const TextStyle(fontSize: 18)),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  value: language,
                  decoration: const InputDecoration(border: OutlineInputBorder()),
                  items: const [
                    DropdownMenuItem(value: 'ar', child: Text('العربية')),
                    DropdownMenuItem(value: 'en', child: Text('English')),
                    DropdownMenuItem(value: 'fr', child: Text('Français')),
                  ],
                  onChanged: (v) => setState(() => language = v ?? 'ar'),
                ),
                const SizedBox(height: 28),
                SizedBox(height: 54, child: FilledButton(
                  onPressed: _continue,
                  child: Text('enter'.tr(), style: const TextStyle(fontWeight: FontWeight.bold)),
                )),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
