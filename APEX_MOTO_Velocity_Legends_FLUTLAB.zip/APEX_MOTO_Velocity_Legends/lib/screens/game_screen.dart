import 'package:flutter/material.dart';
import 'package:flame/game.dart';
import 'package:easy_localization/easy_localization.dart';
import '../game/traffic_game.dart';
class GameScreen extends StatefulWidget { final String mode; const GameScreen({super.key,required this.mode}); @override State<GameScreen> createState()=>_GameScreenState(); }
class _GameScreenState extends State<GameScreen>{
 late final TrafficGame game;
 @override void initState(){super.initState();game=TrafficGame();}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(widget.mode),actions:[IconButton(onPressed:()=>setState(()=>game.paused=!game.paused),icon:const Icon(Icons.pause))]),body:Stack(children:[
 Positioned.fill(child:GameWidget(game:game)),
 Positioned(left:18,bottom:25,child:Row(children:[_control(Icons.arrow_left,()=>game.steer(-1)),const SizedBox(width:12),_control(Icons.arrow_right,()=>game.steer(1))])),
 Positioned(right:18,bottom:25,child:Column(mainAxisSize:MainAxisSize.min,children:[_control(Icons.speed,game.accelerate),const SizedBox(height:12),_control(Icons.stop,game.brake)])),
 if(game.paused) const Center(child:Card(child:Padding(padding:EdgeInsets.all(20),child:Text('PAUSED',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)))))
 ]));
 Widget _control(IconData icon,VoidCallback fn)=>FloatingActionButton(onPressed:fn,backgroundColor:const Color(0xDDFF642D),child:Icon(icon));
}
