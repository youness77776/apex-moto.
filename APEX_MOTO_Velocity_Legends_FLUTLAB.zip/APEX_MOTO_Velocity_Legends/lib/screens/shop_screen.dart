import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import '../services/progress_service.dart';
class ShopScreen extends StatelessWidget {const ShopScreen({super.key});
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text('shop'.tr())),body:ListView(children:[
 ListTile(leading:const Icon(Icons.monetization_on,color:Colors.amber),title:const Text('5,000 Cash'),subtitle:const Text('Earned through prototype gameplay'),trailing:const Text('FREE'),onTap:()=>ProgressService.addCash(5000)),
 const ListTile(leading:Icon(Icons.diamond,color:Colors.lightBlue),title:Text('Premium currency'),subtitle:Text('Purchases are not enabled in this starter project.')),
 const ListTile(leading:Icon(Icons.workspace_premium),title:Text('VIP'),subtitle:Text('Billing requires verified store products and parental compliance.')),
 const Padding(padding:EdgeInsets.all(16),child:Text('No real-money purchases or live ads are active in this prototype. Configure and test these services before any release.')),
 ]));
}
