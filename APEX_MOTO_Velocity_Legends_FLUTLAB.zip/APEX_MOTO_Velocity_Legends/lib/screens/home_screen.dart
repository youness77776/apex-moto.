import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'modes_screen.dart';
import 'garage_screen.dart';
import 'shop_screen.dart';

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState()=>_HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen>{
  String country=''; bool safe=false;
  @override void initState(){super.initState();_load();}
  Future<void> _load() async {final p=await SharedPreferences.getInstance();setState((){country=p.getString('country')??'Worldwide';safe=p.getBool('safe_mode')??false;});}
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('APEX MOTO'),actions:[Padding(padding:const EdgeInsets.all(12),child:Center(child:Text('🌍 $country')))]),
    body:Padding(padding:const EdgeInsets.all(18),child:Column(children:[
      const Spacer(),const Icon(Icons.two_wheeler,size:110,color:Color(0xFFFF642D)),
      const Text('VELOCITY LEGENDS',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900,letterSpacing:2)),
      const SizedBox(height:8),if(safe) Text('safe_mode'.tr(),style:const TextStyle(color:Colors.greenAccent)),
      const Spacer(),
      _tile(context,'garage'.tr(),Icons.garage,()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const GarageScreen()))),
      _tile(context,'modes'.tr(),Icons.flag,()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const ModesScreen()))),
      _tile(context,'shop'.tr(),Icons.store,()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const ShopScreen()))),
      const Spacer(),Text('APEX MOTO • Prototype 1.0',style:TextStyle(color:Colors.white54)),
    ])));
  Widget _tile(BuildContext c,String title,IconData icon,VoidCallback tap)=>Padding(padding:const EdgeInsets.symmetric(vertical:6),child: SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:tap,icon:Icon(icon),label:Padding(padding:const EdgeInsets.all(12),child:Text(title)))));
}
