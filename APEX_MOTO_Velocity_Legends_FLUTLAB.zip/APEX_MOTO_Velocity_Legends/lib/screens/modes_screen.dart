import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'game_screen.dart';
class ModesScreen extends StatelessWidget { const ModesScreen({super.key});
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text('modes'.tr())),body:ListView(children:[
 for(final mode in ['career','endless','time_trial','race','explore']) ListTile(leading:const Icon(Icons.sports_motorsports,color:Colors.orange),title:Text(mode.tr()),subtitle:const Text('Offline prototype'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>GameScreen(mode:mode.tr())))),
 ListTile(leading:const Icon(Icons.people),title:Text('multiplayer'.tr()),subtitle:Text('online_soon'.tr()),onTap:()=>showDialog(context:context,builder:(_)=>AlertDialog(title:Text('multiplayer'.tr()),content:Text('online_soon'.tr()),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:Text('back'.tr()))]))),
 ]));
}
