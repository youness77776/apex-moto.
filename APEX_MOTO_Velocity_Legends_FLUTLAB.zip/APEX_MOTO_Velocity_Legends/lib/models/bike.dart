class Bike {
  final String name;
  final int price;
  final int maxSpeed;
  final bool premium;
  const Bike(this.name, this.price, this.maxSpeed, {this.premium = false});
}
const bikes = <Bike>[
  Bike('PARS 220',0,140), Bike('Falcon 250',12000,165), Bike('Desert Wolf 300',25000,180),
  Bike('City Shark 400',45000,195), Bike('Night Rider 500',70000,210), Bike('Atlas 600',95000,225),
  Bike('Sahara X 700',130000,240), Bike('Cobra 800',180000,255), Bike('Phantom 900',240000,270),
  Bike('Storm 1000',320000,285), Bike('LEGEND HYPER 1100',500,310,premium:true),
  Bike('GHOST NINJA 1200',800,325,premium:true), Bike('GOLDEN FALCON 1300',1200,340,premium:true),
  Bike('DARK VORTEX 1400',1500,355,premium:true), Bike('FIRE DRAGON 1500',2000,370,premium:true),
  Bike('THUNDER KING 1600',2500,390,premium:true), Bike('ULTRA PHANTOM 1700',3000,410,premium:true),
  Bike('WORLD BEAST 1800',3500,430,premium:true), Bike('INFERNO X 2000',5000,450,premium:true),
  Bike('APEX GOD MOTO 2500',8000,500,premium:true),
];
