import 'dart:math';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';

class TrafficGame extends FlameGame {
  double speed = 0;
  double distance = 0;
  double lane = 0;
  double _spawn = 0;
  final Random _random = Random();
  final List<Offset> cars = [];
  bool paused = false;

  void accelerate() { if (!paused) speed = (speed + 1.8).clamp(0, 280); }
  void brake() { speed = (speed - 4).clamp(0, 280); }
  void steer(double direction) { lane = (lane + direction * .07).clamp(-.34,.34); }

  @override
  void update(double dt) {
    super.update(dt);
    if (paused) return;
    speed = (speed - dt * 2).clamp(0, 280);
    distance += speed * dt / 3600;
    _spawn += dt;
    if (_spawn > 1.15) { _spawn=0; cars.add(Offset((_random.nextDouble()-.5)*.48, -.15)); }
    for (var i=0;i<cars.length;i++) {
      cars[i]=Offset(cars[i].dx,cars[i].dy + dt*(.18 + speed/600));
    }
    cars.removeWhere((c)=>c.dy>1.2);
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final w=size.x, h=size.y;
    canvas.drawRect(Offset.zero & Size(w,h), Paint()..color=const Color(0xFF93B7C7));
    canvas.drawRect(Rect.fromLTWH(0,h*.35,w,h*.65), Paint()..color=const Color(0xFF555B60));
    final road=Path()..moveTo(w*.27,h*.35)..lineTo(w*.73,h*.35)..lineTo(w*1.1,h)..lineTo(-w*.1,h)..close();
    canvas.drawPath(road,Paint()..color=const Color(0xFF252A30));
    final line=Paint()..color=Colors.white.withOpacity(.8)..strokeWidth=4;
    for(int i=0;i<8;i++){
      final y=h*.38 + ((i*70 + distance*120)%h*.62);
      canvas.drawLine(Offset(w*.5,y),Offset(w*.5,y+25),line);
    }
    final carPaint=Paint()..color=const Color(0xFFE64B35);
    for(final c in cars){
      final x=w*(.5+c.dx+lane), y=h*(.4+c.dy*.55);
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center:Offset(x,y),width:w*.095,height:h*.12),const Radius.circular(8)),carPaint);
    }
    final bikePaint=Paint()..color=const Color(0xFFFF6A21);
    final bx=w*(.5+lane), by=h*.82;
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center:Offset(bx,by),width:w*.09,height:h*.19),const Radius.circular(16)),bikePaint);
    canvas.drawCircle(Offset(bx,by+h*.07),w*.025,Paint()..color=Colors.black);
    final tp=TextPainter(text:TextSpan(text:'${speed.toInt()} km/h',style:const TextStyle(color:Colors.white,fontSize:20,fontWeight:FontWeight.bold)),textDirection:TextDirection.ltr)..layout();
    tp.paint(canvas,const Offset(18,18));
  }
}
