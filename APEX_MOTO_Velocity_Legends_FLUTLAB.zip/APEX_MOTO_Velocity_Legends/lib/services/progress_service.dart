import 'package:shared_preferences/shared_preferences.dart';
class ProgressService {
  static Future<int> cash() async => (await SharedPreferences.getInstance()).getInt('cash') ?? 5000;
  static Future<void> addCash(int amount) async {
    final p=await SharedPreferences.getInstance();
    await p.setInt('cash',(p.getInt('cash')??5000)+amount);
  }
  static Future<void> saveBike(String name) async =>
    (await SharedPreferences.getInstance()).setString('selected_bike',name);
}
